
/**
 * Write a description of class tlp1 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class tlp1 extends JPanel implements ActionListener{
    JLabel o;
    public static void main (String[] Args){
     tlp1 content = new tlp1();
     JFrame window = new JFrame("tlp1");
     window.setContentPane( content);
     window.setSize(350,100);
     window.setLocation(100, 100);
     window.setVisible(true);
    }//end main
    public tlp1 ()
    {
        o=new JLabel ("O");
        
        JButton left = new JButton ("Left");
        o.setFont (new Font ("Arial", Font.PLAIN, 40));
        
        add (left);
        add (o);
        left.addActionListener (this);
        left.setActionCommand ("left");
        
        JButton right = new JButton ("Right");
        
        right.addActionListener (this);
        right.setActionCommand ("right"); 
        
        add (right);
    }
    public void actionPerformed (ActionEvent e){
        if (e.getActionCommand().equals ("left")){
            o.setLocation (2,10);
        }
        else if (e.getActionCommand().equals ("right")){
            o.setLocation (300,10);
        }
    }
}